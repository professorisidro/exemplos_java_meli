package br.com.meli.profiles;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfilesApplicationTests {

	@Test
	void contextLoads() {
	}

}
