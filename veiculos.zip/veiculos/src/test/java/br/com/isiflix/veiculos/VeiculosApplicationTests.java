package br.com.isiflix.veiculos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VeiculosApplicationTests {

	@Test
	void contextLoads() {
	}

}
