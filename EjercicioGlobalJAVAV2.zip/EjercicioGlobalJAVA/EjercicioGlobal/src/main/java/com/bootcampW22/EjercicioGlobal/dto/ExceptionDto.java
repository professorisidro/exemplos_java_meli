package com.bootcampW22.EjercicioGlobal.dto;

public record ExceptionDto (String message) {
}
