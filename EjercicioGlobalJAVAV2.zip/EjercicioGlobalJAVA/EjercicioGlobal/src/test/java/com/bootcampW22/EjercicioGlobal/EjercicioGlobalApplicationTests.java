package com.bootcampW22.EjercicioGlobal;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioGlobalApplicationTests {

	@Test
	void contextLoads() {
	}

}
