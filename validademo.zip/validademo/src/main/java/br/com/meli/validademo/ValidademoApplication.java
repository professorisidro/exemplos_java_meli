package br.com.meli.validademo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ValidademoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ValidademoApplication.class, args);
	}

}
