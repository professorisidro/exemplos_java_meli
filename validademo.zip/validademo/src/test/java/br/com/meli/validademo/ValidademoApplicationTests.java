package br.com.meli.validademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ValidademoApplicationTests {

	@Test
	void contextLoads() {
	}

}
