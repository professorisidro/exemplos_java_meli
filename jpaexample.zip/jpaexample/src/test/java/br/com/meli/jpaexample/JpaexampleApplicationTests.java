package br.com.meli.jpaexample;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JpaexampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
